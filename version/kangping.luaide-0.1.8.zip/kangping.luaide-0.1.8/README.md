
# LuaIde 
1. author:kangping  
1. **luaIde** 是基于vscode开发的一款用于lua语言开发者使用的插件  
1. 目标:致力于做最好的**跨平台**lua开发工具  
1. 更新:luaide 个人开发者开发持续更新 (**更新频率为一周一更**) 
1. 是否开源:开源
1. 平台支持:**win**,**mac**  

#重要提示
1.  [LuaDebug 下载地址](https://github.com/k0204/LuaIde/tree/master/luadebug)
2.  文档请直接查看[wiki](https://github.com/k0204/LuaIde/wiki)
3.  qq群 **494653114** 
# 下一版本 0.1.9  修改内容
1. 修改模板文件及模板方法的bug
2. 添加非.lua 文件 的配置方法
3. 修改控制台输出方式

#更新记录
1. 0.1.8
	1. 根据 [guoweidong1987](https://github.com/guoweidong1987) 提供的方法修改lua代码格式化
	2. 添加 **luaide.ChangeTextCheck** 代码修改时是否检查lua语法是否正确
	3. 添加模块方法 **luaide.moduleFunNestingCheck**  模块方法嵌套检查,如果在一个方法中出现另外一个模块方法会认为是错误的
	4. 修改**self** 提示bug  无法提示三级和三级以上的代码  如 **self.data.index** 
	5. 添加  **require**  时 lua 文件路径提示
	
1. 0.1.7
	1. 添加显示介绍页面配置 **luaide.isShowDest** 默认为false 只显示一次,如需重复显示修改为true
	2. 修改代码格式化 换行处理 和 " 转义 bug
	3. 修改代码提示  function  方法中 定义的local 变量 无法提示 二级变量 的bug
	4. 添加数据统计接口 统计在线人数, 如果有反感这一行为的请联系我,后期考虑添加配置
	5. 优化debug  将 lua 和luajit 调试文件进行分离 coocs 和unity 如果使用luajit 的调试文件请使用luaDebugjit.lua 文件进行调试  调试文件地址为luadeubg/LuaDebug.lua or luadebug/Luadebugjit.lua
	 

1. 0.1.6 修改代码格式化bug   
1. 将源代码提交至github 


# 捐献      
支持LuaIde的开发 可以通过微信  
![IDE](https://coding.net/u/k0204/p/imgres/git/raw/master/money.png)
